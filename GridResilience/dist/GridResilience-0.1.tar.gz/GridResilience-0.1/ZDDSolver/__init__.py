import numpy as np
import subprocess
from tqdm import tqdm
from GridResilience.Environment import *
import platform


class ZDDSolver:
    def __init__(self):
        self.sysstr = platform.system()
        if self.sysstr == 'Windows':
            self.zdd = "reliability.exe"
        elif self.sysstr == 'Linux':
            self.zdd = "./reliability"
        else:
            raise EnvironmentError
        self.terminal_file = "terminal.dat"
        self.graph_file = "graph.dat"
        self.probability_file = "probability.dat"
        self.solve_cmd = str.split(f"{self.zdd} {self.graph_file} {self.terminal_file} {self.probability_file}")

    def solve(self, case, node=None, source=None):
        np.savetxt(self.graph_file, np.int_(case.edge_array), fmt="%d")
        np.savetxt(self.probability_file, case.linesafe[:, -1].reshape(1, -1), fmt="%.4f")

        def _gen_terminal(src, i):
            np.savetxt(self.terminal_file, np.int_(np.array([src, i]).reshape(1, -1)), fmt="%d")

        def _gen_terminal_list(src, loads):
            node_list = [src]
            node_list.extend(loads)
            np.savetxt(self.terminal_file, np.int_(np.array(node_list).reshape(1, -1)), fmt="%d")

        if node is None:
            prob = np.ones(len(case.bus))
            for i in tqdm(range(1, len(case.bus)), desc='节点概率计算进度：'):
                if source is None:
                    _gen_terminal(src=case.source_idx[0][0], i=i)
                else:
                    _gen_terminal(src=source, i=i)
                output = subprocess.check_output(self.solve_cmd, stderr=subprocess.STDOUT).decode()
                start = output.find('prob = ')
                output = output[start:].split('\n')[0]
                end = output.find('\r')
                res_str = output[7:end]
                prob[i] = float(res_str)
        elif isinstance(node, int):
            i = node
            if source is None:
                _gen_terminal(src=case.source_idx[0][0], i=i)
            else:
                _gen_terminal(src=source, i=i)
            output = subprocess.check_output(self.solve_cmd, stderr=subprocess.STDOUT).decode().split('\n')[5]
            start = output.find('prob = ')
            prob = float(output[start + 7:])
        elif isinstance(node, list):
            if source is None:
                _gen_terminal_list(src=case.source_idx[0][0], loads=node)
            else:
                _gen_terminal_list(src=source, loads=node)
            output = subprocess.check_output(self.solve_cmd, stderr=subprocess.STDOUT).decode().split('\n')[5]
            start = output.find('prob = ')
            prob = float(output[start + 7:])
        else:
            raise ValueError
        return prob


if __name__ == "__main__":
    # branch = np.array([10001.00000, 0.00000, 1.00000, 311.00000, 0.00000,
    #                    10002.00000, 0.00000, 2.00000, 311.00000, 0.00000,
    #                    10003.00000, 1.00000, 3.00000, 311.00000, 0.00000,
    #                    10003.00000, 2.00000, 3.00000, 311.00000, 0.00000,
    #                    ]).reshape(-1, 5)
    # bus = np.array([0.00000, 0.00000, 5.00000, 110.00000, 1.00000, 0.00000, 1.00000, 0.00000,
    #                 1.00000, 0.00000, 3.00000, 333.00000, 1.00000, 21.70000, 0.00000, 0.00000,
    #                 2.00000, -2.00000, 1.00000, 333.00000, 1.00000, 94.20000, 0.00000, 0.00000,
    #                 3.00000, 2.00000, 1.00000, 333.00000, 1.00000, 47.80000, 0.00000, 0.00000,
    #                 ]).reshape(-1, 8)
    # linesafe = np.array([0.9] * len(branch)).reshape(-1, 1)
    # case = Case().from_array(branch, bus, linesafe)
    filepath = '../../data/'
    station_name = '4'
    case = Case().from_file(filepath=filepath, station_name=station_name)
    solver = ZDDSolver()
    res_a = solver.solve(case)
    case.linesafe[-1] += 1e-3
    res_b = solver.solve(case)
    print(f'sense = {np.abs(res_a[2] - res_b[2]) / 1e-3}')
