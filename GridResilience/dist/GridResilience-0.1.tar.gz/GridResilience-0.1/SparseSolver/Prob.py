from copy import deepcopy
import networkx as nx
from tqdm import tqdm
import numpy as np
import ray.util.multiprocessing as mp
from scipy.sparse import coo_matrix, spmatrix
from scipy.sparse.linalg import inv, spsolve
from GridResilience.Environment import *
from numpy.linalg import norm
from math import prod


def _create_fun_element(ind, uv, x_vec, source_list, G_edge_dict, adj, adj_dict, fun_vec):
    u, v = ind
    if u in source_list:
        fun_ele = -x_vec[uv]
    elif v in source_list:
        fun_ele = -x_vec[uv] + adj
    else:
        fun_ele = adj * (1 - prod([1 - x_vec[G_edge_dict[(v, nbr)]] for nbr in adj_dict[v] if nbr != u])) - x_vec[uv]
    fun_vec[uv] = fun_ele


def _create_function(fun_vec, x_vec, source_list, G_edge_dict, adj, adj_dict):
    for i, ind in enumerate(G_edge_dict):
        _create_fun_element(ind, i, x_vec, source_list, G_edge_dict, adj[i], adj_dict, fun_vec)


def _create_fun_c(uv, x_vec, fun_vec, nbr):
    fun_vec[uv] = prod([x_vec[nb] for nb in nbr])


def _create_function_with_ind(fun_vec, x_vec, adj, a, b, c, n):
    local_x = 1 - x_vec
    for k in range(len(c)):
        _create_fun_c(c[k], local_x, fun_vec, n[k])
    # numpy element-wise operations to accelerate vector construction
    fun_vec[a] = -x_vec[a]
    fun_vec[b] = adj[b] - x_vec[b]
    fun_vec[c] = adj[c] * (1 - fun_vec[c]) - x_vec[c]


def _create_function_index(source_list, G_edge_dict, adj_dict):
    a_list, b_list, c_list, nbr_list = [], [], [], []
    a_append = a_list.append
    b_append = b_list.append
    c_append = c_list.append
    nbr_append = nbr_list.append
    for i, (u, v) in enumerate(G_edge_dict):
        if u in source_list:
            a_append(i)
        elif v in source_list:
            b_append(i)
        else:
            c_append(i)
            nbr_append([G_edge_dict[(v, nbr)] for nbr in adj_dict[v] if nbr != u])
    return np.array(a_list), np.array(b_list), np.array(c_list), nbr_list


def prob_multi_station(filePath: str, station_list: list):
    ...


def prob_multi_period(case: Case, funtol=1e-5, itermax=100, t_list=None):
    """
    多时段求解概率
    :param case: 算例对象
    :param funtol: 方程求解精度，默认为1e-5
    :param itermax: 方程求解最大迭代次数，默认为100
    :param t_list: 方程求解时段范围，默认为None，设置时采用list对象
    :return:
    """
    adj_data = _adj_data(case)

    def remote_prob(t):
        return _solve_with_data(case, funtol, itermax, t, adj_data)

    pool = mp.Pool()
    if t_list is None:
        prob_list = pool.map_async(remote_prob, range(np.size(case.linesafe, axis=1))).get()
        prob_all = np.concatenate([p[0] for p in prob_list], axis=1)
        jac_all = [p[1] for p in prob_list]
        return prob_all, jac_all
    else:
        try:
            prob_list = pool.map_async(remote_prob, list(t_list)).get()
            prob_all = np.concatenate([p[0] for p in prob_list], axis=1)
            jac_all = [p[1] for p in prob_list]
            return prob_all, jac_all
        except ValueError:
            print('时间段设置有误')


def _adj_data(case: Case):
    source_list = set(case.source_idx[0])  # 电源节点列表
    G = case.graph  # 读取算例的networkx网络图
    adj = G.adj
    adj_dict = [None for _ in range(len(adj))]  # 算例的邻接字典
    G_edge_list = [e for e in G.edges]  # 算例的边列表
    G_edge_dict = {}  # 算例的边编号字典映射
    bus_num = np.size(case.bus, axis=0)
    for k in adj:
        adj_dict[k] = set([nbr for nbr in adj[k]])
    x_row = []
    x_col = []
    for ind, edge in enumerate(G_edge_list):
        x, y = edge[0], edge[1]
        x_row.append(x)
        x_row.append(y)
        x_col.append(y)
        x_col.append(x)
        G_edge_dict[(x, y)] = ind * 2
        G_edge_dict[(y, x)] = ind * 2 + 1
    a_l, b_l, c_l, n_l = _create_function_index(source_list, G_edge_dict, adj_dict)
    return source_list, adj_dict, G_edge_list, G_edge_dict, bus_num, G, a_l, b_l, c_l, n_l


def _solve_with_data(case, funtol, itermax, t, data_tuple=None, need_x=False, need_f=False):
    sparse_jac = None
    if data_tuple is None:
        data_tuple = _adj_data(case)
    source_list, adj_dict, G_edge_list, G_edge_dict, bus_num, G, a_type, b_type, c_type, nbr_l = data_tuple
    ls = 1 - case.linesafe[:, t]
    ea = case.edge_array
    # 第一部分：生成邻接矩阵数据
    full_num = len(G_edge_dict)
    data = np.ones(full_num)
    for ind, (u, v) in enumerate(ea):
        data[G_edge_dict[(u, v)]] *= ls[ind]
        data[G_edge_dict[(v, u)]] *= ls[ind]
    data = 1.0 - data
    # 第二部分：生成函数矢量
    x = np.ones(full_num)
    fun = np.zeros(full_num)
    _create_function_with_ind(fun, x, data, a_type, b_type, c_type, nbr_l)
    # 第三部分：迭代求解部分
    iter_count = 0
    # Jacobian 矩阵索引确定
    jac_rows = []
    jac_cols = []
    row_append = jac_rows.append
    col_append = jac_cols.append
    for ind in range(full_num // 2):
        i, j = G_edge_list[ind]
        if j not in source_list:
            for k in adj_dict[j]:
                if k != i:
                    row_append(G_edge_dict[(i, j)])
                    col_append(G_edge_dict[(j, k)])
        if i not in source_list:
            for k in adj_dict[i]:
                if k != j:
                    row_append(G_edge_dict[(j, i)])
                    col_append(G_edge_dict[(i, k)])
    full_ind = range(full_num)
    jac_cols.extend(full_ind)
    jac_rows.extend(full_ind)
    jac_data = np.zeros(len(jac_cols))
    jac_index = []
    jac_R = []
    R_append = jac_R.append
    cursor = 0
    while norm(fun, ord=np.inf) > funtol and iter_count < itermax:
        x = 1 - x
        if sparse_jac is None:
            for ind, (i, j) in enumerate(G_edge_list):
                ij = 2 * ind
                local_data = data[ij]
                if j not in source_list:
                    for k in adj_dict[j]:
                        if k != i:
                            jac_index.append([G_edge_dict[(j, tt)] for tt in adj_dict[j] if tt != k and tt != i])
                            jac_data[cursor] = local_data * prod(
                                [x[jac_ind] for jac_ind in jac_index[cursor]])
                            R_append(local_data)
                            cursor += 1
                if i not in source_list:
                    for k in adj_dict[i]:
                        if k != j:
                            jac_index.append([G_edge_dict[(i, tt)] for tt in adj_dict[i] if tt != k and tt != j])
                            jac_data[cursor] = local_data * prod(
                                [x[jac_ind] for jac_ind in jac_index[cursor]])
                            R_append(local_data)
                            cursor += 1
            jac_data[cursor:] = -1.0
            sparse_jac = coo_matrix((jac_data, (jac_rows, jac_cols)), shape=(full_num, full_num))
        else:
            for c, j_inds in enumerate(jac_index):
                jac_data[c] = prod([x[j_i] for j_i in j_inds])
            jac_data[:cursor] *= jac_R
            sparse_jac.data = jac_data
        dx = spsolve(sparse_jac.tocsc(), fun)  # 稀疏直接求解
        x = 1 - x - dx
        _create_function_with_ind(fun, x, data, a_type, b_type, c_type, nbr_l)
        iter_count += 1
    # 第四部分：节点概率计算部分
    p = np.zeros((bus_num, 1))
    x = 1 - x
    for i in range(bus_num):
        if i not in source_list:
            p[i] = prod([x[G_edge_dict[(i, nbr)]] for nbr in adj_dict[i]])
    p = 1 - p
    if need_x and not need_f:
        return p, sparse_jac, 1 - x
    elif need_f and not need_x:
        return p, sparse_jac, fun
    elif need_f and need_x:
        return p, sparse_jac, 1 - x, fun
    else:
        return p, sparse_jac


def prob_solver(case: Case, funtol=1e-5, itermax=100, t=0, adj_data=None):
    """
    单一时刻求解边缘概率
    :param case: CPSCase 算例对象
    :param funtol: 方程求解精度，默认为1e-5
    :param itermax: 方程最大迭代次数，默认为100
    :param t: 方程求解时段，默认为0时刻
    :return: p: 节点有电概率
             jac: 最后一次计算的Jacobian矩阵
    """
    if adj_data is None:
        p, jac = _solve_with_data(case, funtol, itermax, t, _adj_data(case))
    else:
        p, jac = _solve_with_data(case, funtol, itermax, t, adj_data)
    return p, jac


def risk_assessment(case: Case, res_array=None, funtol=1e-5, itermax=100, t=0):
    if res_array is None:
        res_array, _ = _solve_with_data(case, funtol, itermax, t, _adj_data(case))
    return np.sum(case.bus[:, PLOAD] * case.bus[:, VALUE] * (1 - res_array.flatten()))


def _perturbation_for_edges(case: Case, funtol=1e-5, itermax=100, t=0):
    adj = _adj_data(case)
    ref_p, _ = _solve_with_data(case, funtol, itermax, t, adj)
    ref_risk = risk_assessment(case, res_array=ref_p)
    disturbance = 1e-8
    pool = mp.Pool()

    def _perturbation(i):
        test_case = deepcopy(case)
        test_case.linesafe[i, t] -= disturbance
        p, _ = _solve_with_data(test_case, funtol, itermax, t, adj)
        return np.abs(
            ref_risk - risk_assessment(case, res_array=p)) / disturbance

    partial_risk = pool.map_async(_perturbation, tqdm(range(len(case.branch)))).get()

    return np.array(partial_risk)


def _analytical_sensitivity(case: Case, funtol=1e-5, itermax=100, t=0, adj_data=None, solver_result=None,
                            node_wise=False, risk=False):
    if adj_data is None:
        adj = _adj_data(case)
    else:
        adj = adj_data
    if solver_result is None:
        ref_p, ref_jac, x = _solve_with_data(case, funtol, itermax, t, adj, need_x=True)
    else:
        ref_p, ref_jac, x = solver_result

    if isinstance(ref_jac, spmatrix):
        ref_jac = ref_jac.tocsc()
    source_list, adj_dict, G_edge_list, G_edge_dict, bus_num, G, a_type, b_type, c_type, nbr_l = adj
    sense = np.zeros((len(case.bus), len(case.branch)))
    dx_mat = -inv(ref_jac)
    if risk:
        value_mat = case.bus[:, PLOAD] * case.bus[:, VALUE]
    else:
        value_mat = np.ones((len(case.bus), 1))
    for i, j in G.edges:
        edge_ind = case.edge_dict[Case.edge_to_key((i, j))]
        para_edge_list = case.multiple_edge[Case.edge_to_key((i, j))]
        ij = G_edge_dict[(i, j)]
        ji = G_edge_dict[(j, i)]
        for n in G.nodes:
            if value_mat[n] != 0:
                i_temp, j_temp = np.zeros(1), np.zeros(1)
                for k in adj_dict[n]:
                    nk = G_edge_dict[(n, k)]
                    j_temp += dx_mat[nk, ij] / (1 - x[nk])
                    i_temp += dx_mat[nk, ji] / (1 - x[nk])
                if i not in source_list:
                    for p in para_edge_list:
                        sense[n, p] += prod([1 - case.linesafe[kk, :] for kk in para_edge_list if kk != p]) * x[
                            ji] * i_temp * value_mat[n] * (1 - ref_p[n]) / (1 - np.prod(1 - case.linesafe[para_edge_list, t]))
                else:
                    for p in para_edge_list:
                        sense[n, p] += prod([1 - case.linesafe[kk, :] for kk in para_edge_list if kk != p]) * i_temp * \
                                       value_mat[n] * (1 - ref_p[n])
                if j not in source_list:
                    for p in para_edge_list:
                        sense[n, p] += prod([1 - case.linesafe[kk, :] for kk in para_edge_list if kk != p]) * x[
                            ij] * j_temp * value_mat[n] * (1 - ref_p[n]) / (1 - np.prod(1 - case.linesafe[para_edge_list, t]))
                else:
                    for p in para_edge_list:
                        sense[n, p] += prod([1 - case.linesafe[kk, :] for kk in para_edge_list if kk != p]) * j_temp * \
                                       value_mat[n] * (1 - ref_p[n])
    if node_wise:
        return sense
    else:
        return np.sum(sense, axis=0)


def sensitivity(case, method='a', solver_result=None, node_wise=False):
    """

    :param case: CPSCase 算例对象
    :param method: 'a'：解析法  'n'：数值法
    :param solver_result: 求解得到的信息（p, jac, x）
    :return:
    """
    if method == 'n':
        return _perturbation_for_edges(case)
    elif method == 'a':
        return _analytical_sensitivity(case, solver_result=solver_result, node_wise=node_wise)
    else:
        raise ValueError("输入方法参数有误，应为'n'(数值法)或'a'(解析法)")


if __name__ == "__main__":
    from line_profiler import LineProfiler
    from time import time

    import ray

    #
    # ray.init()

    # 单元测试环境设置
    lp = LineProfiler()
    station_name = 'beiliuzhan'
    filepath = '../../data/'
    case = Case().from_file(filepath=filepath, station_name=station_name)
    case.linesafe = case.linesafe - case.linesafe + 0.9
    # res = []
    #
    # for i in range(100):
    #     case.linesafe = (i + 1) * 0.01 * np.ones((np.size(case.linesafe, axis=0), 16))
    #     res.append(risk_assessment(case))
    # import matplotlib.pyplot as plt
    #
    # plt.plot((1 + np.array(range(100))) * 0.01, np.array(res))
    # plt.show()

    # 单时段求解测试
    # lp.add_function(_create_fun_element)
    # lp.add_function(_solve_with_data)
    # lp.add_function(_create_function)
    # lp.add_function(_adj_data)
    # lp.add_function(_create_function_index)
    # lp_wrapper = lp(prob_solver)
    # lp_wrapper(case)

    # 多时段求解测试
    # if not ray.is_initialized():
    #     ray.init()
    # lp_wrapper = lp(prob_multi_period)
    # lp_wrapper(case)

    # 打印性能检测
    # lp.print_stats()

    # 结果测试
    st = time()
    first_layer, _ = prob_solver(case)
    print(f'单一算例计算时间为{time() - st}')

    # 灵敏度
    # edge_sense_a = sensitivity(case, method='a', node_wise=True)
    # edge_sense_n = sensitivity(case, method='n').reshape(1, -1)
    # print(f'2-Norm为{np.linalg.norm(edge_sense_a - edge_sense_n)}')
    # lp.add_function(_analytical_sensitivity)
    # lp_wrapper = lp(sensitivity)
    # res = lp_wrapper(case)
    # lp.print_stats()
