# 算例的索引文件， 适用于广州算例格式
FBUS = 1
TBUS = 2
ISTRANS = 4
COM_I = 5
BAT = 6
BRH_I = 0
