from copy import deepcopy
import numpy as np
import networkx as nx
from GridResilience.Environment import *
from GridResilience.SparseSolver import *
import matplotlib.pyplot as plt
from GridResilience.Inference.pyAgrumInf import *
import os


def network_outage_inference(case: Case, survive: list, fail: list):
    # 先验知识层
    first_layer = None
    # 后验推断层
    fail = fail[0]
    inference_graph = deepcopy(case.graph)
    inference_graph.remove_node(fail)
    line_inf = np.zeros(len(case.branch))
    frozen_line_safe = deepcopy(case.linesafe)
    line_fail = 1 - case.linesafe
    ref_p, _ = prob_solver(case)
    print(f'ref = {ref_p}')
    local_case = deepcopy(case)
    ind = []
    for i in inference_graph.edges:
        ind.append(local_case.edge_dict[i])
    for i in tqdm(ind):
        local_case.linesafe = deepcopy(frozen_line_safe)
        local_case.linesafe[i, :] *= 0.0
        p, _ = prob_solver(local_case, funtol=1e-10)
        line_inf[i] = 1 - (1 - p[fail]) * line_fail[i] / (1 - ref_p[fail])
    print(line_inf)
    local_case.linesafe = line_inf.reshape(-1, 1)
    ind = np.array(ind)
    branch = case.branch[ind, :]
    bus = case.bus
    linesafe = line_inf[ind].reshape(-1, 1)
    inf_case = Case().from_array(branch, bus, linesafe)
    final_p, _ = prob_solver(inf_case, funtol=1e-10)
    return final_p


if __name__ == "__main__":
    # station_name = 'IEEE14'
    # filepath = '../../data/'
    # case = Case().from_file(filepath=filepath, station_name=station_name)
    branch = np.array([10001.00000, 0.00000, 1.00000, 311.00000, 0.00000,
                       10002.00000, 1.00000, 2.00000, 311.00000, 0.00000,
                       ]).reshape(-1, 5)
    bus = np.array([0.00000, 0.00000, 5.00000, 110.00000, 1.00000, 0.00000, 1.00000, 0.00000,
                    1.00000, 0.00000, 3.00000, 333.00000, 1.00000, 21.70000, 0.00000, 0.00000,
                    2.00000, -2.00000, 1.00000, 333.00000, 1.00000, 94.20000, 0.00000, 0.00000,

                    ]).reshape(-1, 8)
    linesafe = np.array([0.9] * len(branch)).reshape(-1, 1)
    linesafe[-1] = 0.99
    case = Case().from_array(branch, bus, linesafe)
    survive = []
    fail = [2]
    bayes_res = do_inference(case, survive=survive, lost=fail, new_file=True)
    ref, _ = prob_solver(case)

    res = network_outage_inference(case, survive, fail)

    # plt.plot(range(len(case.bus)), res)
    # plt.show()
